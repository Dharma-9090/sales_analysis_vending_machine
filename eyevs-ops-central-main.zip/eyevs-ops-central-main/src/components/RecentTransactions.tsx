import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CreditCard, Banknote, Smartphone } from "lucide-react";

const transactions = [
  {
    id: "TXN001",
    machine: "VM001",
    item: "Coca Cola",
    amount: "$2.50",
    paymentMethod: "card",
    time: "2 min ago",
    status: "completed"
  },
  {
    id: "TXN002",
    machine: "VM005",
    item: "Energy Drink",
    amount: "$3.75",
    paymentMethod: "mobile",
    time: "5 min ago",
    status: "completed"
  },
  {
    id: "TXN003",
    machine: "VM002",
    item: "Water Bottle",
    amount: "$1.25",
    paymentMethod: "cash",
    time: "8 min ago",
    status: "completed"
  },
  {
    id: "TXN004",
    machine: "VM001",
    item: "Chips",
    amount: "$2.00",
    paymentMethod: "card",
    time: "12 min ago",
    status: "failed"
  },
  {
    id: "TXN005",
    machine: "VM004",
    item: "Candy Bar",
    amount: "$1.75",
    paymentMethod: "mobile",
    time: "15 min ago",
    status: "completed"
  }
];

export const RecentTransactions = () => {
  const getPaymentIcon = (method: string) => {
    switch (method) {
      case "card":
        return <CreditCard className="w-4 h-4 text-primary" />;
      case "cash":
        return <Banknote className="w-4 h-4 text-success" />;
      case "mobile":
        return <Smartphone className="w-4 h-4 text-accent" />;
      default:
        return null;
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-foreground flex items-center justify-between">
          Recent Transactions
          <Badge variant="outline" className="text-success border-success">
            Live
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {transactions.map((transaction) => (
            <div key={transaction.id} className="flex items-center justify-between p-3 rounded-lg bg-secondary/50">
              <div className="flex items-center space-x-3">
                {getPaymentIcon(transaction.paymentMethod)}
                <div>
                  <div className="font-medium text-foreground">
                    {transaction.item} - {transaction.machine}
                  </div>
                  <div className="text-sm text-muted-foreground">
                    {transaction.id} • {transaction.time}
                  </div>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <div className="text-right">
                  <div className="text-sm font-medium text-foreground">{transaction.amount}</div>
                  <div className="text-xs text-muted-foreground capitalize">{transaction.paymentMethod}</div>
                </div>
                <Badge 
                  variant={transaction.status === "completed" ? "secondary" : "destructive"}
                  className={transaction.status === "completed" ? "text-success border-success" : ""}
                >
                  {transaction.status}
                </Badge>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};
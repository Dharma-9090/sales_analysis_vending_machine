import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { AlertTriangle, CheckCircle, Clock } from "lucide-react";

const inventoryData = [
  { item: "Coca Cola", stock: 45, threshold: 20, status: "good" },
  { item: "Pepsi", stock: 12, threshold: 20, status: "low" },
  { item: "Water Bottles", stock: 67, threshold: 30, status: "good" },
  { item: "Chips", stock: 8, threshold: 15, status: "critical" },
  { item: "Candy Bars", stock: 23, threshold: 20, status: "good" },
  { item: "Energy Drinks", stock: 18, threshold: 25, status: "low" }
];

export const InventoryTable = () => {
  const getStatusIcon = (status: string) => {
    switch (status) {
      case "good":
        return <CheckCircle className="w-4 h-4 text-success" />;
      case "low":
        return <Clock className="w-4 h-4 text-warning" />;
      case "critical":
        return <AlertTriangle className="w-4 h-4 text-destructive" />;
      default:
        return null;
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "good":
        return <Badge variant="secondary" className="text-success border-success">Good</Badge>;
      case "low":
        return <Badge variant="secondary" className="text-warning border-warning">Low</Badge>;
      case "critical":
        return <Badge variant="secondary" className="text-destructive border-destructive">Critical</Badge>;
      default:
        return null;
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-foreground flex items-center justify-between">
          Inventory Levels
          <Badge variant="outline" className="text-destructive border-destructive">
            {inventoryData.filter(item => item.status === 'critical').length} Critical
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {inventoryData.map((item, index) => (
            <div key={index} className="flex items-center justify-between p-3 rounded-lg bg-secondary/50">
              <div className="flex items-center space-x-3">
                {getStatusIcon(item.status)}
                <div>
                  <div className="font-medium text-foreground">{item.item}</div>
                  <div className="text-sm text-muted-foreground">
                    Threshold: {item.threshold} units
                  </div>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <div className="text-right">
                  <div className="text-sm font-medium text-foreground">{item.stock} units</div>
                  <div className="text-xs text-muted-foreground">Current</div>
                </div>
                {getStatusBadge(item.status)}
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Activity, DollarSign, Package, TrendingUp, Zap, AlertTriangle } from "lucide-react";
import { MetricsCard } from "./MetricsCard";
import { StatusIndicator } from "./StatusIndicator";
import { SalesChart } from "./SalesChart";
import { InventoryTable } from "./InventoryTable";
import { RecentTransactions } from "./RecentTransactions";

export const Dashboard = () => {
  const metrics = [
    {
      title: "Daily Revenue",
      value: "$2,847",
      change: "+12%",
      icon: DollarSign,
      trend: "up" as const
    },
    {
      title: "Active Machines",
      value: "24/26",
      change: "92%",
      icon: Activity,
      trend: "stable" as const
    },
    {
      title: "Transactions Today",
      value: "342",
      change: "+8%",
      icon: TrendingUp,
      trend: "up" as const
    },
    {
      title: "Low Stock Alerts",
      value: "3",
      change: "Alert",
      icon: Package,
      trend: "warning" as const
    }
  ];

  const machineStatuses = [
    { id: "VM001", location: "Building A Lobby", status: "online", revenue: "$145" },
    { id: "VM002", location: "Building B Floor 2", status: "online", revenue: "$98" },
    { id: "VM003", location: "Cafeteria Main", status: "offline", revenue: "$0" },
    { id: "VM004", location: "Library Entrance", status: "maintenance", revenue: "$67" },
    { id: "VM005", location: "Gym Complex", status: "online", revenue: "$203" }
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="border-b border-border bg-card">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-foreground">EyeVs Operations</h1>
              <p className="text-muted-foreground">Vending Machine DX Management Dashboard</p>
            </div>
            <div className="flex items-center space-x-4">
              <Badge variant="outline" className="text-success border-success">
                <Zap className="w-3 h-3 mr-1" />
                Live
              </Badge>
              <StatusIndicator status="operational" />
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="container mx-auto px-6 py-6 space-y-6">
        {/* Metrics Overview */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {metrics.map((metric, index) => (
            <MetricsCard key={index} {...metric} />
          ))}
        </div>

        {/* Charts and Analytics */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-foreground">Sales Analytics</CardTitle>
            </CardHeader>
            <CardContent>
              <SalesChart />
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-foreground flex items-center justify-between">
                Machine Status
                <Badge variant="secondary" className="text-xs">
                  {machineStatuses.filter(m => m.status === 'online').length} Online
                </Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {machineStatuses.map((machine) => (
                  <div key={machine.id} className="flex items-center justify-between p-3 rounded-lg bg-secondary/50">
                    <div>
                      <div className="font-medium text-foreground">{machine.id}</div>
                      <div className="text-sm text-muted-foreground">{machine.location}</div>
                    </div>
                    <div className="flex items-center space-x-3">
                      <div className="text-right">
                        <div className="text-sm font-medium text-foreground">{machine.revenue}</div>
                        <div className="text-xs text-muted-foreground">Today</div>
                      </div>
                      <StatusIndicator 
                        status={machine.status as "online" | "offline" | "maintenance"} 
                        size="sm" 
                      />
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Tables */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <InventoryTable />
          <RecentTransactions />
        </div>
      </div>
    </div>
  );
};
import { cn } from "@/lib/utils";

interface StatusIndicatorProps {
  status: "online" | "offline" | "maintenance" | "operational";
  size?: "sm" | "md" | "lg";
}

export const StatusIndicator = ({ status, size = "md" }: StatusIndicatorProps) => {
  const getStatusConfig = (status: string) => {
    switch (status) {
      case "online":
      case "operational":
        return {
          color: "bg-success",
          label: status === "online" ? "Online" : "Operational",
          pulse: true
        };
      case "offline":
        return {
          color: "bg-destructive",
          label: "Offline",
          pulse: false
        };
      case "maintenance":
        return {
          color: "bg-warning",
          label: "Maintenance",
          pulse: true
        };
      default:
        return {
          color: "bg-muted-foreground",
          label: "Unknown",
          pulse: false
        };
    }
  };

  const config = getStatusConfig(status);
  
  const sizeClasses = {
    sm: "w-2 h-2",
    md: "w-3 h-3",
    lg: "w-4 h-4"
  };

  return (
    <div className="flex items-center space-x-2">
      <div className="relative">
        <div className={cn(
          "rounded-full",
          config.color,
          sizeClasses[size]
        )} />
        {config.pulse && (
          <div className={cn(
            "absolute inset-0 rounded-full animate-ping opacity-75",
            config.color,
            sizeClasses[size]
          )} />
        )}
      </div>
      <span className="text-sm font-medium text-foreground">{config.label}</span>
    </div>
  );
};
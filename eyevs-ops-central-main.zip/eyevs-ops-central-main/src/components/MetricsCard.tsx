import { Card, CardContent } from "@/components/ui/card";
import { LucideIcon, TrendingUp, TrendingDown, Minus } from "lucide-react";
import { cn } from "@/lib/utils";

interface MetricsCardProps {
  title: string;
  value: string;
  change: string;
  icon: LucideIcon;
  trend: "up" | "down" | "stable" | "warning";
}

export const MetricsCard = ({ title, value, change, icon: Icon, trend }: MetricsCardProps) => {
  return (
    <Card className="border-border bg-card hover:bg-card/80 transition-colors">
      <CardContent className="p-6">
        <div className="flex items-center justify-between">
          <div className="space-y-2">
            <p className="text-sm font-medium text-muted-foreground">{title}</p>
            <div className="space-y-1">
              <p className="text-2xl font-bold text-foreground">{value}</p>
              <div className="flex items-center space-x-1">
                {trend === "up" && <TrendingUp className="w-3 h-3 text-success" />}
                {trend === "down" && <TrendingDown className="w-3 h-3 text-destructive" />}
                {trend === "stable" && <Minus className="w-3 h-3 text-muted-foreground" />}
                {trend === "warning" && <TrendingUp className="w-3 h-3 text-warning" />}
                <span className={cn(
                  "text-xs font-medium",
                  trend === "up" && "text-success",
                  trend === "down" && "text-destructive",
                  trend === "stable" && "text-muted-foreground",
                  trend === "warning" && "text-warning"
                )}>
                  {change}
                </span>
              </div>
            </div>
          </div>
          <div className={cn(
            "p-3 rounded-lg",
            trend === "up" && "bg-success/10",
            trend === "down" && "bg-destructive/10",
            trend === "stable" && "bg-secondary",
            trend === "warning" && "bg-warning/10"
          )}>
            <Icon className={cn(
              "w-6 h-6",
              trend === "up" && "text-success",
              trend === "down" && "text-destructive",
              trend === "stable" && "text-muted-foreground",
              trend === "warning" && "text-warning"
            )} />
          </div>
        </div>
      </CardContent>
    </Card>
  );
};